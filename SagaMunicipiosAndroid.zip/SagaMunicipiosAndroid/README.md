# SAGA: Municípios do Brasil — projeto Android

Projeto Android Studio que empacota a versão web da roleta em um aplicativo Android usando WebView.

## Abrir e compilar
1. Instale o Android Studio em um computador.
2. Abra a pasta `SagaMunicipiosAndroid` no Android Studio.
3. Aguarde a sincronização do Gradle e instale o Android SDK 35 se solicitado.
4. Para testar: conecte um celular Android com depuração USB ou use um emulador e clique em Run.
5. Para gerar APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

## Progresso
O WebView tem JavaScript e DOM storage habilitados para permitir que o `localStorage` da página guarde o progresso localmente no dispositivo. A persistência depende da lógica de salvamento existente no HTML. Os dados não são sincronizados entre dispositivos.

## Publicação
Este projeto é um ponto de partida e ainda precisa ser compilado e testado em dispositivos reais. Para publicar na Google Play, será necessário gerar e assinar um Android App Bundle, criar uma ficha da loja, fornecer ícone/capturas de tela/política de privacidade e cumprir os requisitos vigentes do Google Play Console.
